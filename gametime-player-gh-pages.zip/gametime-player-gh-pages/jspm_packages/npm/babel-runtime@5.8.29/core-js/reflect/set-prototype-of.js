/* */ 
module.exports = { "default": require("core-js/library/fn/reflect/set-prototype-of"), __esModule: true };