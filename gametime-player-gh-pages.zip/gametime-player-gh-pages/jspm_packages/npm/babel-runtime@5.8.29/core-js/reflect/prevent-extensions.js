/* */ 
module.exports = { "default": require("core-js/library/fn/reflect/prevent-extensions"), __esModule: true };