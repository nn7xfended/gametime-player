/* */ 
module.exports = { "default": require("core-js/library/fn/math/sign"), __esModule: true };