/* */ 
module.exports = { "default": require("core-js/library/fn/array/filter"), __esModule: true };