/* */ 
module.exports = { "default": require("core-js/library/fn/array/from"), __esModule: true };