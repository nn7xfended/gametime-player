/* */ 
module.exports = { "default": require("core-js/library/fn/object/get-prototype-of"), __esModule: true };