/* */ 
module.exports = { "default": require("core-js/library/fn/object/get-own-property-names"), __esModule: true };