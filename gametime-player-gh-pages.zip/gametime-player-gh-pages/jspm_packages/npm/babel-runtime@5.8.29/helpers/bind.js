/* */ 
"use strict";

exports["default"] = Function.prototype.bind;
exports.__esModule = true;