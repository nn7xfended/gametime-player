/* */ 
"use strict";

exports["default"] = function (strings, raw) {
  strings.raw = raw;
  return strings;
};

exports.__esModule = true;