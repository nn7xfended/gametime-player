define(["github:stuk/jszip@2.5.0/dist/jszip"], function(main) {
  return main;
});