/* */ 
"format global";
import install from "./install";

install();
