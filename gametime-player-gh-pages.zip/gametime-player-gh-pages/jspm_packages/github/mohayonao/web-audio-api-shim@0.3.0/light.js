/* */ 
"format global";
module.exports = require("./lib/install")(0);
