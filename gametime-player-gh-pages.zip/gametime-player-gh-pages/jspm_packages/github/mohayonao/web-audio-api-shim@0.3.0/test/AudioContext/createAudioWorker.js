/* */ 
(function() {
  "use strict";

  describe.skip("AudioContext.prototype.createAudioWorker", function() {
    describe("(scriptURL: string, numberOfInputChannels: number, numberOfOutputChannels: number): AudioNode", function() {
      it("should return an AudioNode as AudioWorkerNode", function() {
      });
    });
  });
})();
