define(["github:satazor/sparkmd5@1.0.1/spark-md5"], function(main) {
  return main;
});