export * from "github:matthewbauer/document@0.0.4/document";
export {default} from "github:matthewbauer/document@0.0.4/document";