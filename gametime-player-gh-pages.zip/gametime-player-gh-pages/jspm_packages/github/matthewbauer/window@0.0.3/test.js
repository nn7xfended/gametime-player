import {XMLHttpRequest} from './window'
console.error(XMLHttpRequest)
